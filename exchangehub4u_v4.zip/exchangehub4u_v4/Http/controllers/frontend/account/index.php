<?php

use Core\Session;
use Core\Database;
use Core\App;
// dd($_SESSION);

$db = App::resolve(Database::class);
$userId = (int) Session::get('id');

// Check if a customer with this user ID exists
$customer = $db->query('SELECT * FROM customer WHERE user_id = ?', [$userId])->find();

// if (Session::has('id') && Session::get('profile') == 'false') { 
//     redirect('/account/create');
// }else{

if (Session::has('id') && !$customer){
    redirect('/account/create');
}else{
    $result = $db->query(
        'SELECT * FROM customer c INNER JOIN user u ON c.user_id = u.user_id WHERE c.user_id = :id',
         ['id' => $userId]
     )->find();
     
    // dd($result);


        view("account/index.view.php", [
        'heading' => 'My Account',
        'user' => $result,
        'errors' => [],
    ]);
}


