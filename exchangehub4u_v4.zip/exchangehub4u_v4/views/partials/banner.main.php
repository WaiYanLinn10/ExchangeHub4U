<header class="mb-5 img-background">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-7 mx-auto text-center text-dark p-4">
                <h1 class="text-uppercase" style="font-size: 50px; text-shadow: 2.5px 2.5px #7f7f7f;">Today's Best Deals</h1>

                <a class="btn mt-5 px-4 py-3 rounded-0 shadow-sm primary-btn" href="/shop">SHOP NOW</a>
            </div>
        </div>
    </div>
</header>