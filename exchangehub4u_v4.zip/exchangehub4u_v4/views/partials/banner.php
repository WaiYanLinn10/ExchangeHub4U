<header class="img-background mb-5" style="height: 270px; filter: saturate(1.2); background-position:center;">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-7 text-dark p-4">
                <h1 class="text-uppercase mb-4">Shop With Us</h1>

                <p class="d-inline p-2">
                    <a class="link-secondary color-1 text-decoration-none" href="/">Home</a><span class="text-dark"> - <?= $heading ?></span>
                </p>
            </div>
        </div>
    </div>
</header>
