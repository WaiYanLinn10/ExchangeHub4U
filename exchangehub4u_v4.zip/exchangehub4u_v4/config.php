<?php

return [
    'database' => [
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => 'exchangehub4u',
        'charset' => 'utf8mb4'
    ],

    //
];