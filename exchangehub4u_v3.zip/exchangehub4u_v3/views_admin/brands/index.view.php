<?php require base_path('views_admin/partials/head.php') ?>


<div class="container-fluid px-4 mt-5">
    <h4><?= $heading; ?></h4>

    <div class="card mt-5 border-0 shadow-sm">
        <div class="card-content">
            <div class="card-body p-4">
                <button class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#addBrandModal">Add Brand</button>

                <table class="table mt-4 text-center">
                    <thead class="bg-light border-bottom border-1 border-dark">
                        <tr>
                            <th>No.</th>
                            <th>Brand Name</th>
                            <th>Brand Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($brands as $brand) { ?>
                        <tr>
                            <td><?= $i++; ?></td>
                            <td><?= $brand['brand_name']; ?></td>
                            <td>
                                <img src="../images/brands/<?= $brand['brand_img']; ?>" class="img-fluid me-2" style="height: 75px;" alt="brand Image">
                            </td>
                            <td>
                                <a href="#" class="text-decoration-none text-secondary" data-bs-toggle="modal" data-bs-target="#deleteBrandModal<?= $brand['brand_id']; ?>">
                                    <i class="fa-solid fa-trash"></i>
                                </a>
                                <a href="#" class="text-decoration-none text-secondary" data-bs-toggle="modal" data-bs-target="#editBrandModal<?= $brand['brand_id']; ?>">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                            </td>
                        </tr>
                        <?php
                            require "delete.view.php";
                            require "edit.view.php";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require "add.view.php"; ?>

<?php require base_path('views_admin/partials/footer.php') ?>