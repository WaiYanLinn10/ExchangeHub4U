<?php

view_admin("index.view.php", [
    'heading' => 'Manage Categories',
]);
