<?php

view_admin("index.view.php", [
    'heading' => 'Manage FAQ',
]);
