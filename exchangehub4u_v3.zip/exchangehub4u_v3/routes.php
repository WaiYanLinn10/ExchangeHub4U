<?php

$router->get('/', 'frontend/index.php');
$router->get('/about', 'frontend/about.php');
$router->get('/contact', 'frontend/contact.php');
$router->get('/shop', 'frontend/shop.php');

$router->get('/product','frontend/product/index.php');

$router->get('/register', 'frontend/registration/create.php')->only('guest');
$router->post('/register', 'frontend/registration/store.php')->only('guest');

$router->get('/login', 'frontend/session/create.php')->only('guest');
$router->post('/session', 'frontend/session/store.php')->only('guest');
$router->delete('/session', 'frontend/session/destroy.php')->only('auth');

$router->get('/account/index', 'frontend/account/index.php')->only('auth') ;
$router->get('/account/create', 'frontend/account/create.php')->only('auth');
$router->post('/account', 'frontend/account/store.php');
$router->patch('/account/update/info','frontend/account/update.info.php');
$router->patch('/account/update/pwd','frontend/account/update.pwd.php');
$router->delete('/account','frontend/account/destory.php');

$router->get('/cart', 'frontend/shoppingcart/index.php');
$router->post('/cart', 'frontend/shoppingcart/add.php');
$router->delete('/cart','frontend/shoppingcart/destory.php');

$router->get('/wishlist','frontend/wishlist/index.php');
$router->post('/wishlist', 'frontend/wishlist/add.php');
$router->delete('/wishlist', 'frontend/wishlist/destory.php'); 

$router->post('/checkout', 'frontend/checkout/index.php');
$router->post('/order', 'frontend/checkout/order_add.php');

$router->get('/admin', 'backend/index.php');

$router->get('/admin/order','backend/orders/index.php');
$router->get('/admin/order/show','backend/orders/show.php');
$router->delete('/admin/order','backend/orders/destory.php');

$router->get('/admin/product','backend/products/index.php');
$router->get('/admin/product/show','backend/products/show.php');
$router->post('/admin/product','backend/products/store.php');
$router->patch('/admin/product','backend/products/update.php');
$router->delete('/admin/product','backend/products/destory.php');

$router->get('/admin/admin','backend/admins/index.php');
$router->post('/admin/admin','backend/admins/store.php');
$router->patch('/admin/admin','backend/admins/update.php');
$router->delete('/admin/admin','backend/admins/destory.php');



$router->get('/admin/customer','backend/customers/index.php');
$router->get('/admin/customer/show','backend/customers/show.php');
$router->post('/admin/customer','backend/customers/store.php');
$router->patch('/admin/customer','backend/customers/update.php');
$router->delete('/admin/customer','backend/customers/destory.php');

$router->get('/admin/brand','backend/brands/index.php');
$router->post('/admin/brand','backend/brands/store.php');
$router->patch('/admin/brand','backend/brands/update.php');
$router->delete('/admin/brand','backend/brands/destory.php');


$router->get('/admin/category','backend/categories/index.php');
$router->post('/admin/category','backend/categories/store.php');
$router->patch('/admin/category','backend/categories/update.php');
$router->delete('/admin/category','backend/categories/destory.php');


$router->get('/admin/faq','backend/faq/index.php');




